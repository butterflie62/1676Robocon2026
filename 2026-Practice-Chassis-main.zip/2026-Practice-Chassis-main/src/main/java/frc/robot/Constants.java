// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

package frc.robot;

import com.pathplanner.lib.config.PIDConstants;
import com.pathplanner.lib.config.RobotConfig;
import edu.wpi.first.math.geometry.Translation3d;
import edu.wpi.first.math.interpolation.InterpolatingDoubleTreeMap;
import edu.wpi.first.math.util.Units;
import edu.wpi.first.wpilibj.DigitalInput;
import swervelib.math.Matter;

/**
 * The Constants class provides a convenient place for teams to hold robot-wide numerical or boolean constants. This
 * class should not be used for any other purpose. All constants should be declared globally (i.e. public static). Do
 * not put anything functional in this class.
 *
 * <p>It is advised to statically import this class (or one of its inner classes) wherever the
 * constants are needed, to reduce verbosity.
 */
public final class Constants
{
  public static final double ROBOT_MASS = (148 - 20.3) * 0.453592; // 32lbs * kg per pound
  public static final Matter CHASSIS    = new Matter(new Translation3d(0, 0, Units.inchesToMeters(8)), ROBOT_MASS);
  public static final double LOOP_TIME  = 0.13; //s, 20ms + 110ms sprk max velocity lag
  public static final double MAX_SPEED  = Units.feetToMeters(14.5);
  public static final double DEADBAND  = 0.1;

  public static final class Pathplanner 
  { 
    public static RobotConfig PATHPLANNER_ROBOT_CONFIG;
    public static PIDConstants TRANSLATIONAL_PID = new PIDConstants(1.170, 0, 0); // Translational
    public static PIDConstants ROTATIONAL_PID = new PIDConstants(2.875, 0, 0.1); // Rotational PID

    public static void configurePathplanner () {
      try {
        PATHPLANNER_ROBOT_CONFIG = RobotConfig.fromGUISettings();
      } catch (Exception e) {
          e.printStackTrace();
          System.out.println("Robot Config for Pathplanner not working");
      }
    }
  }

  public static final class Alliance 
  {
    public static final int SWITCH_DIO_CHANNEL = 0; 
    public static DigitalInput allianceSwitch = new DigitalInput(SWITCH_DIO_CHANNEL);
    
    public static boolean BLUE() { 
      return allianceSwitch.get();   
    }
    public static boolean RED (){
      return !allianceSwitch.get(); 
    }

    public static boolean RED = RED(); 
    public static boolean BLUE = BLUE(); 
  }

  public static final class DrivebaseConstants
  {
    // Hold time on motor brakes when disabled
    public static final double WHEEL_LOCK_TIME = 10; // seconds
    public static final double FINE_DRIVE_SPEED = 1.5; //Normal = 1.6

    public static final int FRD_PDP_PORT = 0;//Front Right Drive
    public static final int FRA_PDP_PORT = 1;//Front Right Angle
    public static final int FLD_PDP_PORT = 2;//Front Left Drive
    public static final int FLA_PDP_PORT = 13;//Front Left Angle
    public static final int BRD_PDP_PORT = 19;//Back Right Drive
    public static final int BRA_PDP_PORT = 18;//Back Right Angle
    public static final int BLD_PDP_PORT = 17;//Back Left Drive
    public static final int BLA_PDP_PORT = 16;//Back Left Angle
  }

  public static class OperatorConstants
  {
    // Joystick Deadband
    public static final double DEADBAND        = 0.1;
    public static final double LEFT_Y_DEADBAND = 0.1;
    public static final double RIGHT_X_DEADBAND = 0.1;
    public static final double TURN_CONSTANT    = 6;
    public static final int RIGHT_Y = 5;
    public static final int LEFT_Y = 1;
  }

  public static final class Hub {
    public static double getTargetX() { return Alliance.RED() ? 11.9155 : 4.630; } //469.115 inches (red) // (blue) 4.630 meters = 182.11 inches
    public static final double TARGET_Y = 4.03; //4.03 meters = 158.845 inches
    public static final double ANGLE_TOLERANCE = 1;
  }

  public static final class Pass {
    public static double getTargetXLeft() { return Alliance.RED() ? 15 : 2.0; }
    public static final double TARGET_Y_LEFT =  6.5;

    public static double getTargetXRight() { return Alliance.RED() ? 15 : 2.0; }
    public static final double TARGET_Y_RIGHT =  1.5;
  }

  public static final class Limelight {

    public static final String LIMELIGHT_RIGHT_NAME = "limelight-right";
    public static final String LIMELIGHT_LEFT_NAME = "limelight-left";
    public static final String LIMELIGHT_FRONT_NAME = "limelight-front";

    public static final int LIMELIGHT_RIGHT_PIPELINE_INDEX = 1;
    public static final int LIMELIGHT_LEFT_PIPELINE_INDEX = 1;
    public static final int LIMELIGHT_FRONT_PIPELINE_INDEX = 1;
  }

  public static final class Intake {

    public static final int MOTOR_ID = 27; 
    
    public static final double SPEED = -0.80;  

    public static final double RAMP_TIME = 0.75;
    
    public static final double CURRENT_LIMIT = 20.0; 

    public static final int PDP_PORT = 4;

  }


  public static final class Kicker {

    public static final int MOTOR_ID = 33;

    public static final double KICKER_SPEED = 0.75;

    public static final int PDP_PORT = 14;

  }

  public static final class Indexer {
    
    public static final int MOTOR_ID = 60;

    public static final double INDEXER_SPEED = -0.60;
    
    public static final double RAMP_TIME = 0.5;

    public static final double CURRENT_LIMIT = 20.0; 

    public static final int PDP_PORT = 6;

  }

  public static final class Hood {
    
    public static final int MOTOR_ID = 51;

    public static final double SPEED = 0.05; 

    public static final double PASSING_POSITION = 0.900;

    public static final double kP = 0.750;
    public static final double kI = 0.0; 
    public static final double kD = 0.001; 
    public static final double PID_TOLERANCE = 0.05; 

    public static final double STOWED_POSITION = 0; 
    public static final double MIN_POSITION = 0; 
    public static final double MAX_POSITION = 0.950;
    
    public static final int PDP_PORT = 7;
  }

  public static final class Pivot {

    public static final int MOTOR_ID = 31; 

    public static final double SPEED = -0.25; 

    public static final double MAX_SPEED = 240.0; 
    public static final double MAX_ACCELERATION = 250.0; 
    public static final double MAX_JERK = 10000.0; 

    public static final double kS = 0.356; 
    public static final double kV = 0.0814;
    public static final double kA = 0.0061113;
    public static final double kP = 0.05;
    public static final double kI = 0.0;
    public static final double kD = 0.0;
    public static final double kG = 0.10669;

    public static final double STOWED_POSITION = 0.500; // stowed is always 0
    public static final double INTAKE_POSITION = -39.91;
    public static final double AGITATE_POSITION = -22.5;
    public static final double AGITATE_FURTHER_POSITION = -12.55;


    public static final int PDP_PORT = 5;

  }

  public static final class Shooter {
    public static final double TEST_RPM = 4200; // rpm for getting data points
    public static final double PASSING_RPM = 4200; // rpm for passing the ball to another robot with drum shooter
    public static final int BACKUP_RPM = 3700; // optimal for close-mid, NOT for far away 
    public static final int BACKUP_RPM_BOOST = 4175; // optimal for close-mid, NOT for far away 


    public static final int MOTOR_L1_ID = 42;
    public static final int MOTOR_L2_ID = 43;
    public static final int MOTOR_R1_ID = 40;
    public static final int MOTOR_R2_ID = 41;

    public static final double kP = 0.0005; //0.0005
    public static final double kI = 0.0; //0.0
    public static final double kD = 0.00001; //0.00001

    public static final double RAMP_TIME = 0.5; // seconds to go from 0 to full throttle
    public static final double WAIT_TIME = 1.0; 

    public static final int UPPER_RIGHT_PDP_PORT = 10;
    public static final int LOWER_RIGHT_PDP_PORT = 11;
    public static final int UPPER_LEFT_PDP_PORT = 13;
    public static final int LOWER_LEFT_PDP_PORT = 12; 
    
    public static final InterpolatingDoubleTreeMap TOF = new InterpolatingDoubleTreeMap();
    public static final InterpolatingDoubleTreeMap RPM = new InterpolatingDoubleTreeMap();
    public static final InterpolatingDoubleTreeMap HOOD_ANGLE = new InterpolatingDoubleTreeMap();

    public static void setUpRPM() { 
      RPM.put(1.5, 3425.0); //2500
      RPM.put(2.0, 3625.0); //2750
      RPM.put(2.5, 3625.0); //2750
      RPM.put(3.0, 3775.0); //2850
      RPM.put(3.5, 4025.0); //3100
      RPM.put(4.0, 4175.0); //3250
      RPM.put(4.5, 4225.0); //3250

    }
    
    public static void setUpHoodAngle() { 
      HOOD_ANGLE.put(1.5, 0.325);
      HOOD_ANGLE.put(2.0, 0.425);
      HOOD_ANGLE.put(2.5, 0.585);
      HOOD_ANGLE.put(3.0, 0.700);
      HOOD_ANGLE.put(3.5, 0.850); 
      HOOD_ANGLE.put(4.0, 0.900);
     HOOD_ANGLE.put(4.5, 0.900);

    }

    public static void setUpTOF() {
      TOF.put(1.5, 1.0);
      TOF.put(2.0, 1.08);
      TOF.put(2.5, 1.11);
      TOF.put(3.0, 1.13);
      TOF.put(3.5, 1.12);
      TOF.put(4.0, 1.28);
      // TOF.put(4.5, 1.28);

    }
  }

}
