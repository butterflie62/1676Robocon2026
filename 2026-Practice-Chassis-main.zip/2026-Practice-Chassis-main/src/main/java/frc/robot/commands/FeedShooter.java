package frc.robot.commands;

import edu.wpi.first.wpilibj2.command.ParallelCommandGroup;
import frc.robot.Constants;
import frc.robot.subsystems.Indexer;
import frc.robot.subsystems.Kicker;

public class FeedShooter extends ParallelCommandGroup{
    public FeedShooter (Kicker kicker, Indexer indexer) {
        addCommands(
            new SpinKicker (kicker, Constants.Kicker.KICKER_SPEED),
            new SpinIndexer (indexer, () -> Constants.Indexer.INDEXER_SPEED)
        );
    }
}
