package frc.robot.commands;

import edu.wpi.first.wpilibj2.command.ParallelCommandGroup;
import frc.robot.Constants;
import frc.robot.subsystems.Intake;
import frc.robot.subsystems.Pivot;

public class AgitateFurther extends ParallelCommandGroup {
    public AgitateFurther (Pivot pivot, Intake intake) {
        addCommands(
            new PivotGoTo(pivot, Constants.Pivot.AGITATE_FURTHER_POSITION), 
            new SpinIntake(intake, Constants.Intake.SPEED/2)
        );
    }
}
