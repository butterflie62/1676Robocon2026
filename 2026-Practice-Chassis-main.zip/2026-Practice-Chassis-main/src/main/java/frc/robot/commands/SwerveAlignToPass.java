package frc.robot.commands;

import edu.wpi.first.math.MathUtil;
import edu.wpi.first.math.geometry.Pose2d;
import edu.wpi.first.math.geometry.Rotation2d;
import edu.wpi.first.math.kinematics.ChassisSpeeds;
import edu.wpi.first.wpilibj2.command.Command;
import frc.robot.Constants;
import frc.robot.subsystems.swervedrive.SwerveSubsystem;

import java.util.function.DoubleSupplier;

public class SwerveAlignToPass extends Command {

    private SwerveSubsystem swerve;
    private DoubleSupplier translationXSupplier; // tracker for x velocity to account for robot moving while aligning to hub
    private DoubleSupplier translationYSupplier; // tracker for y velocity to account for robot moving while aligning to hub


    public SwerveAlignToPass(SwerveSubsystem swerve, DoubleSupplier translationXSupplier, DoubleSupplier translationYSupplier) {
        this.swerve = swerve;
        this.translationXSupplier = translationXSupplier;
        this.translationYSupplier = translationYSupplier;

        swerve.setHeadingCorrection(true);
        addRequirements(swerve);
    }

    @Override
    public void execute() {
        // Get robot pose from swerve (already fused with vision via Limelight integration)
        Pose2d robotPose = swerve.getPose();

        double targetX = Constants.Pass.getTargetXLeft();
        double targetY = Constants.Pass.TARGET_Y_LEFT;

        if(robotPose.getY() < 4) {
            targetX = Constants.Pass.getTargetXRight();
            targetY = Constants.Pass.TARGET_Y_RIGHT;
        }
        
        // Calculate the angle from the robot to the target
        // This angle points FROM the robot TO the target
        Rotation2d angleToTarget = calculateAngleToTarget(robotPose, targetX, targetY);
   
        Rotation2d targetAngle = angleToTarget.plus(new Rotation2d(Math.PI));

        // Get user translation inputs to allow driving while aligning
        double xInput = MathUtil.applyDeadband(translationXSupplier.getAsDouble(), Constants.DEADBAND);
        double yInput = MathUtil.applyDeadband(translationYSupplier.getAsDouble(), Constants.DEADBAND);
        
        // Use swerve controller to combine user translation with automatic rotation to target
        ChassisSpeeds targetSpeeds = swerve.getSwerveController().getTargetSpeeds(xInput, 
                                        yInput, 
                                        targetAngle.getRadians(), 
                                        swerve.getHeading().getRadians(), 
                                        Constants.MAX_SPEED);
        
        // Drive the robot with the calculated speeds (field-relative)
        
        swerve.driveFieldOriented(targetSpeeds);
    }

    /**
     * Calculate the angle from the robot to the target position.
     * 
     * @param robotPose Current robot pose
     * @param targetX Target X coordinate
     * @param targetY Target Y coordinate
     * @return Rotation2d angle to the target
     */
    private Rotation2d calculateAngleToTarget(Pose2d robotPose, double targetX, double targetY) {
        // Calculate the vector from robot to target
        double deltaX = targetX - robotPose.getX();
        double deltaY = targetY - robotPose.getY();
        
        // Calculate the angle using atan2
        return new Rotation2d(Math.atan2(deltaY, deltaX));
    }

    //  We don't want align to ever end, so that it can lock onto the hub while moving around. 
    //  We can have the align code to toggle on/off

    @Override
    public boolean isFinished() {
        // Never finish and runs continuously until operator releases the button
        // This allows for constant adjustment as the robot moves
        return false; 
    }

    public void end (boolean interrupted) {
        swerve.setHeadingCorrection(false);
    }

}


