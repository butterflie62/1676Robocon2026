package frc.robot.commands;

import java.util.function.DoubleSupplier;

import edu.wpi.first.wpilibj2.command.Command;
import frc.robot.subsystems.Pivot;

public class ControlPivot extends Command {
    private Pivot pivot; 
    private DoubleSupplier speed; 
    
    public ControlPivot (Pivot pivot, DoubleSupplier speed) {
        this.pivot = pivot; 
        this.speed = speed; 
    }

    @Override
    public void execute () {
        pivot.setSpeed(speed.getAsDouble());
    }

    @Override
    public void end(boolean interrupted) {
        pivot.stop(); 
    }
}
