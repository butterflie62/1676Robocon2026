package frc.robot.commands;
import edu.wpi.first.math.MathUtil;
import edu.wpi.first.math.geometry.Rotation2d;
import edu.wpi.first.math.kinematics.ChassisSpeeds;
import edu.wpi.first.wpilibj2.command.Command;
import frc.robot.Constants;
import frc.robot.subsystems.ProjectileEstimation;
import frc.robot.subsystems.swervedrive.SwerveSubsystem;

import java.util.function.DoubleSupplier;

/**
 * Command to automatically align the robot to face the hub/target.
 * Uses the swerve subsystem's integrated vision-corrected pose estimation.
 */

public class AdjustedAlignTo extends Command {
    private SwerveSubsystem swerve;
    private DoubleSupplier translationXSupplier;
    private DoubleSupplier translationYSupplier;
    private ProjectileEstimation estimation;

    public AdjustedAlignTo(SwerveSubsystem swerve,
                    DoubleSupplier translationXSupplier, DoubleSupplier translationYSupplier,
                    ProjectileEstimation estimation) {

        this.swerve = swerve;
        this.estimation = estimation;
        this.translationXSupplier = translationXSupplier;
        this.translationYSupplier = translationYSupplier;

        swerve.setHeadingCorrection(true);

        addRequirements(swerve);
    }

    @Override
    public void execute() {
        Rotation2d angleToTarget = estimation.calculateAdjustedAngleToTarget(Constants.Hub.getTargetX(), Constants.Hub.TARGET_Y).plus(new Rotation2d(Math.PI));
        
        // Get user translation inputs to allow driving while aligning
        double xInput = MathUtil.applyDeadband(translationXSupplier.getAsDouble(), Constants.DEADBAND);
        double yInput = MathUtil.applyDeadband(translationYSupplier.getAsDouble(), Constants.DEADBAND);
        
        // Use swerve controller to combine user translation with automatic rotation to target
        ChassisSpeeds targetSpeeds = swerve.getSwerveController().getTargetSpeeds(xInput, 
                                        yInput, 
                                        angleToTarget.getRadians(), 
                                        swerve.getHeading().getRadians(), 
                                        Constants.MAX_SPEED);
        
        // Drive the robot with the calculated speeds (field-relative)
        swerve.driveFieldOriented(targetSpeeds);
    }

    //  We don't want align to ever end, so that it can lock onto the hub while moving around. 
    //  We can have the align code to toggle on/off

    @Override
    public boolean isFinished() {
        // Never finish and runs continuously until operator releases the button
        // This allows for constant adjustment as the robot moves
        return false; 
    }

    @Override
    public void end (boolean interrupted){
        swerve.setHeadingCorrection(false);
    }

}
