package frc.robot.commands;
import edu.wpi.first.math.MathUtil;
import edu.wpi.first.math.geometry.Pose2d;
import edu.wpi.first.math.geometry.Rotation2d;
import edu.wpi.first.math.kinematics.ChassisSpeeds;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj2.command.Command;
import frc.robot.Constants;
import frc.robot.subsystems.swervedrive.SwerveSubsystem;

import java.util.function.DoubleSupplier;

/**
 * Command to automatically align the robot to face the hub/target.
 * Uses the swerve subsystem's integrated vision-corrected pose estimation.
 */
public class SwerveAlignTo extends Command {
    private SwerveSubsystem swerve;
    private DoubleSupplier translationXSupplier;
    private DoubleSupplier translationYSupplier;

    public SwerveAlignTo(SwerveSubsystem swerve,
                    DoubleSupplier translationXSupplier, DoubleSupplier translationYSupplier) {
        this.swerve = swerve;
        this.translationXSupplier = translationXSupplier;
        this.translationYSupplier = translationYSupplier;

        swerve.setHeadingCorrection(true);
        addRequirements(swerve);
    }

    @Override
    public void execute() {
        Pose2d robotPose = swerve.getPose();
        Rotation2d angleToTarget = calculateAngleToTarget(robotPose, Constants.Hub.getTargetX(), Constants.Hub.TARGET_Y);
   
        Rotation2d targetAngle = angleToTarget.plus(new Rotation2d(Math.PI));
        SmartDashboard.putNumber("Intended Angle of Movement", targetAngle.getDegrees());

        // Get user translation inputs to allow driving while aligning
        double xInput = MathUtil.applyDeadband(translationXSupplier.getAsDouble(), Constants.DEADBAND) * Constants.MAX_SPEED;
        double yInput = MathUtil.applyDeadband(translationYSupplier.getAsDouble(), Constants.DEADBAND) * Constants.MAX_SPEED;
        
        // Use swerve controller to combine user translation with automatic rotation to target
        ChassisSpeeds targetSpeeds = swerve.getSwerveController().getTargetSpeeds(xInput, 
                                        yInput, 
                                        targetAngle.getRadians(), 
                                        swerve.getHeading().getRadians(), 
                                        Constants.MAX_SPEED);
        
        // Drive the robot with the calculated speeds (field-relative)
        swerve.driveFieldOriented(targetSpeeds);
    }

    /**
     * Calculate the angle from the robot to the target position.
     * 
     * @param robotPose Current robot pose
     * @param targetX Target X coordinate
     * @param targetY Target Y coordinate
     * @return Rotation2d angle to the target
     */
    private Rotation2d calculateAngleToTarget(Pose2d robotPose, double targetX, double targetY) {
        // Calculate the vector from robot to target
        double deltaX = targetX - robotPose.getX();
        double deltaY = targetY - robotPose.getY();
        
        // Calculate the angle using atan2
        return new Rotation2d(Math.atan2(deltaY, deltaX));
    }

    //  We don't want align to ever end, so that it can lock onto the hub while moving around. 
    //  We can have the align code to toggle on/off

    @Override
    public boolean isFinished() {
        // Never finish and runs continuously until operator releases the button
        // This allows for constant adjustment as the robot moves
        return false; 
    }

    @Override
    public void end (boolean interrupted) {
        swerve.setHeadingCorrection(false);
    }

}
