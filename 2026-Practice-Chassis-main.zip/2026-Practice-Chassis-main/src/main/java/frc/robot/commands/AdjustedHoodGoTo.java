package frc.robot.commands;

import edu.wpi.first.wpilibj2.command.Command;
import frc.robot.Constants;
import frc.robot.subsystems.Hood;
import frc.robot.subsystems.ProjectileEstimation;

public class AdjustedHoodGoTo extends Command {

    private final Hood hood;
    private final ProjectileEstimation estimation;

    public AdjustedHoodGoTo (Hood hood, ProjectileEstimation estimation) {
        this.hood = hood;
        this.estimation = estimation;

        addRequirements(hood);
    }

    @Override
    public void execute () {
        double position = estimation.getHoodAngle(Constants.Hub.getTargetX(), Constants.Hub.TARGET_Y);
        
        hood.setPose(position);
    }

    @Override
    public void end (boolean interrupted) { 
        hood.stop();
    }

    @Override
    public boolean isFinished () {
        return false; 
    }
    
}
