package frc.robot.commands;

import edu.wpi.first.wpilibj2.command.Command;
import frc.robot.subsystems.Hood;

public class ControlHood extends Command {
    private Hood hood; 
    private final double speed; 
    
    public ControlHood (Hood hood, double speed) {
        this.hood = hood; 
        this.speed = speed; 

        addRequirements(hood);
    }

    @Override 
    public void execute () {
        // if(hood.getPose() >= Constants.Hood.MIN_POSITION && hood.getPose() <= Constants.Hood.MAX_POSITION)
            hood.setSpeed(speed);
    }

    @Override
    public void end (boolean interrupted) { 
        hood.stop();
    }
}
