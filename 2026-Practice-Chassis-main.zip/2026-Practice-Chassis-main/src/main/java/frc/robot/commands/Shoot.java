package frc.robot.commands;

import edu.wpi.first.wpilibj2.command.ParallelCommandGroup;
import frc.robot.subsystems.Kicker;
import frc.robot.subsystems.Hood;
import frc.robot.subsystems.Indexer;
import frc.robot.subsystems.ProjectileEstimation;
import frc.robot.subsystems.Shooter;

public class Shoot extends ParallelCommandGroup{
    public Shoot (Shooter shooter, Hood hood, Kicker kicker, Indexer indexer,
                ProjectileEstimation estimation) {
        addCommands(
            new PrepareShooter(shooter, hood, estimation),
            new DelayedFeedShooter(kicker, indexer)
        );
    }
}
