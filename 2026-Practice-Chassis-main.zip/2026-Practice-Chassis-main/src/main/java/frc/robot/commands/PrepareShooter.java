package frc.robot.commands;

import edu.wpi.first.wpilibj2.command.ParallelCommandGroup;
import frc.robot.subsystems.Shooter;
import frc.robot.subsystems.Hood;
import frc.robot.subsystems.ProjectileEstimation;

public class PrepareShooter extends ParallelCommandGroup{
    public PrepareShooter (Shooter shooter, Hood hood, ProjectileEstimation estimation) {
        addCommands(
            new AdjustedSpinShooter(shooter, estimation),
            new AdjustedHoodGoTo(hood, estimation)
        );
    }
}
