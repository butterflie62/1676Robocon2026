package frc.robot.commands;

import edu.wpi.first.wpilibj2.command.ParallelCommandGroup;
import frc.robot.subsystems.Indexer;
import frc.robot.subsystems.Kicker;
import frc.robot.subsystems.Shooter;

public class CollectShooterData extends ParallelCommandGroup {
    public CollectShooterData(Shooter shooter, Kicker kicker, Indexer indexer, double speed) {
        addCommands(
            new SpinShooter(shooter, speed), 
            new DelayedFeedShooter(kicker, indexer)
        );
    }
}
