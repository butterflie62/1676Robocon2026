package frc.robot.commands;

import edu.wpi.first.wpilibj2.command.ParallelCommandGroup;
import frc.robot.Constants;
import frc.robot.subsystems.Hood;
import frc.robot.subsystems.Shooter;

public class PrepareShooterForPassing extends ParallelCommandGroup{
    public PrepareShooterForPassing(Shooter shooter, Hood hood) {
        addCommands(
            new SpinShooter(shooter, Constants.Shooter.PASSING_RPM), 
            new HoodGoTo(hood, Constants.Hood.PASSING_POSITION)
        );
    }
}
