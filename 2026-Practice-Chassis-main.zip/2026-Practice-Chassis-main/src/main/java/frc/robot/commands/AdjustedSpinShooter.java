package frc.robot.commands; 

import edu.wpi.first.wpilibj2.command.Command;
import frc.robot.Constants;
import frc.robot.subsystems.ProjectileEstimation;
import frc.robot.subsystems.Shooter;

public class AdjustedSpinShooter extends Command {
    private Shooter shooter;
    private ProjectileEstimation estimation;

    public AdjustedSpinShooter(Shooter shooter, ProjectileEstimation estimation) {
        this.shooter = shooter;
        this.estimation = estimation;

        addRequirements(shooter);
    }

    @Override
    public void execute() {
        double rpm = estimation.getRPM(Constants.Hub.getTargetX(), Constants.Hub.TARGET_Y);
        shooter.setShooterSpeed(rpm);
    }

    @Override
    public void end(boolean interrupted) {
        shooter.stop();
    }

    @Override
    public boolean isFinished () {
        return false; //never finished, always adjusting based on distance
    }
    
}
