package frc.robot.commands;

import edu.wpi.first.wpilibj2.command.Command;
import frc.robot.Constants;
import frc.robot.subsystems.Pivot;

public class PivotGoTo extends Command {
    private double setpoint; 
    private Pivot pivot; 

    public PivotGoTo (Pivot pivot, double setpoint) {
        this.pivot = pivot;
        this.setpoint = setpoint;

        addRequirements(pivot);
    }
    
    @Override
    public void execute () {
        pivot.setSpeed(Constants.Pivot.SPEED);
        pivot.setPosition(setpoint);
    }   

    @Override
    public void end (boolean interrupted) {
        pivot.stop(); 
    }

    @Override 
    public boolean isFinished () {
        return pivot.isAtSetpoint(); 
    }
    
}
