package frc.robot.commands;

import java.util.function.DoubleSupplier;

import edu.wpi.first.wpilibj2.command.Command;
import frc.robot.subsystems.Indexer;

public class SpinIndexer extends Command {
    
    private Indexer indexer; 
    private DoubleSupplier speed;

    public SpinIndexer (Indexer indexer, DoubleSupplier speed){ 
        this.indexer = indexer; 
        this.speed = speed; 

        addRequirements(indexer);
    }

    @Override
    public void execute () {
        indexer.setSpeed(speed.getAsDouble());
    }
    
    @Override
    public void end(boolean interrupted) {
        indexer.stop();
    }

}
