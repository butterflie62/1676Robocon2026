package frc.robot.commands;

import edu.wpi.first.wpilibj2.command.SequentialCommandGroup;
import edu.wpi.first.wpilibj2.command.WaitCommand;
import frc.robot.Constants;
import frc.robot.subsystems.Indexer;
import frc.robot.subsystems.Kicker;

public class DelayedFeedShooter extends SequentialCommandGroup{
    public DelayedFeedShooter (Kicker kicker, Indexer indexer){
        addCommands(
            new WaitCommand(Constants.Shooter.WAIT_TIME), 
            new FeedShooter(kicker, indexer)
        );
    }
}
