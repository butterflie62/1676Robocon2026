package frc.robot.commands;

import edu.wpi.first.wpilibj2.command.Command;
import frc.robot.subsystems.Hood;

public class HoodGoTo extends Command {

    private Hood hood; 
    private final double setpoint;

    public HoodGoTo (Hood hood, double setpoint) {
        
        this.hood = hood; 
        this.setpoint = setpoint; 

        addRequirements(hood);
    }

    @Override
    public void execute () { 
        hood.setPose(setpoint);
    }

    @Override
    public void end (boolean interrupted) { 
        hood.stop();
    }

    @Override
    public boolean isFinished () {
        return false; 
    }
    
}
