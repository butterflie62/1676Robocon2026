package frc.robot.commands;

import edu.wpi.first.wpilibj2.command.Command;
import frc.robot.subsystems.Intake;

public class SpinIntake extends Command {
    private Intake intake;
    private double speed;

    public SpinIntake(Intake intake, double speed) {
        this.intake = intake;
        this.speed = speed;

        addRequirements(intake);
    }

    @Override
    public void initialize() {
        intake.setSpeed(speed);
    }

    @Override
    public void end(boolean interrupted) {
        intake.stop();
    }
}