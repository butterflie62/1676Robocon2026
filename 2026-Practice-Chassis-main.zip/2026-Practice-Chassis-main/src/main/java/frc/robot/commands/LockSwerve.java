package frc.robot.commands;

import edu.wpi.first.wpilibj2.command.Command;
import frc.robot.subsystems.swervedrive.SwerveSubsystem;

public class LockSwerve extends Command {
    private SwerveSubsystem swerve;
    public LockSwerve (SwerveSubsystem swerve) {
        this.swerve = swerve;
        addRequirements(swerve);
    }

    @Override
    public void initialize() {
        swerve.setIsLocked(true);
    }

    @Override
    public void execute() {
        swerve.lock();
    }

    @Override
    public void end (boolean interrupted) {
        swerve.setIsLocked(false);
    }
}
