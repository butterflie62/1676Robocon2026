package frc.robot.commands;

import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj2.command.Command;
import frc.robot.subsystems.Shooter;

public class SpinShooter extends Command{ 

    private Shooter shooter; 
    private final double rpm ; 

    public SpinShooter (Shooter shooter, double rpm) {
        this.shooter = shooter; 
        this.rpm = rpm; 

        addRequirements(shooter);
    }

    @Override
    public void execute ()  {

        shooter.setShooterSpeed(rpm); 
        SmartDashboard.putNumber("Shooter RPM", shooter.getRPM());
    }

    @Override 
    public void end (boolean interrupted) {
        shooter.stop(); 
    }
}