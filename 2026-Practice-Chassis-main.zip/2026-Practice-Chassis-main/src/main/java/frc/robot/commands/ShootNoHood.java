package frc.robot.commands;

import edu.wpi.first.wpilibj2.command.ParallelCommandGroup;
import frc.robot.subsystems.Kicker;
import frc.robot.subsystems.Indexer;
import frc.robot.subsystems.ProjectileEstimation;
import frc.robot.subsystems.Shooter;

public class ShootNoHood extends ParallelCommandGroup{
    public ShootNoHood (Shooter shooter, Kicker kicker, Indexer indexer,
                ProjectileEstimation estimation) {
        addCommands(
            new AdjustedSpinShooter(shooter, estimation),
            new DelayedFeedShooter(kicker, indexer)
        );
    }
}
