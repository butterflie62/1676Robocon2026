package frc.robot.commands;

import edu.wpi.first.wpilibj2.command.ParallelCommandGroup;
import frc.robot.Constants;
import frc.robot.subsystems.Intake;
import frc.robot.subsystems.Pivot;

public class Agitate extends ParallelCommandGroup {
    public Agitate (Pivot pivot, Intake intake) {
        addCommands(
            new PivotGoTo(pivot, Constants.Pivot.AGITATE_POSITION), 
            new SpinIntake(intake, Constants.Intake.SPEED/2)
        );
    }
}
