package frc.robot.commands;

import edu.wpi.first.wpilibj2.command.Command;
import frc.robot.subsystems.Kicker;

public class SpinKicker extends Command {
    private Kicker kicker;
    private double speed;

    public SpinKicker(Kicker kicker, double speed) {
        this.kicker = kicker;
        this.speed = speed; 
        addRequirements(kicker);
    }

    @Override
    public void initialize() {
        kicker.setKickerSpeed(speed);
    }

    @Override
    public void end(boolean interrupted) {
        kicker.stop();
    }
}
