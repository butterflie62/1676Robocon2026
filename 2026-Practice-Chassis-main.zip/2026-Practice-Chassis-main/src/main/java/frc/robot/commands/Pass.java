package frc.robot.commands;

import edu.wpi.first.wpilibj2.command.ParallelCommandGroup;
import frc.robot.subsystems.Hood;
import frc.robot.subsystems.Indexer;
import frc.robot.subsystems.Kicker;
import frc.robot.subsystems.Shooter;

public class Pass extends ParallelCommandGroup{
    
    public Pass(Shooter shooter, Hood hood, Kicker kicker, Indexer indexer) {
        addCommands(
            new PrepareShooterForPassing(shooter, hood),
            new DelayedFeedShooter(kicker, indexer)
        );
    }
}
