package frc.robot.subsystems;

import com.ctre.phoenix6.configs.TalonFXConfiguration;
import com.ctre.phoenix6.hardware.TalonFX;
import com.ctre.phoenix6.signals.NeutralModeValue;

import edu.wpi.first.wpilibj2.command.SubsystemBase;
import frc.robot.Constants;

public class Intake extends SubsystemBase {

    private TalonFX intake;
    private TalonFXConfiguration config; 

    public Intake (int MOTOR_ID) {

        intake = new TalonFX(MOTOR_ID);

        config = new TalonFXConfiguration(); 
        config.MotorOutput.NeutralMode = NeutralModeValue.Coast; 
        config.OpenLoopRamps.DutyCycleOpenLoopRampPeriod = Constants.Intake.RAMP_TIME;
        config.CurrentLimits.SupplyCurrentLimit = Constants.Intake.CURRENT_LIMIT;
        config.CurrentLimits.SupplyCurrentLimitEnable = true;

        intake.getConfigurator().apply(config);

    }

    public void setSpeed(double speed) {
        intake.set(speed);
    }

    public double getSpeed() {
        return intake.get();
    }

    public void stop() {
        intake.stopMotor();
    }

}


