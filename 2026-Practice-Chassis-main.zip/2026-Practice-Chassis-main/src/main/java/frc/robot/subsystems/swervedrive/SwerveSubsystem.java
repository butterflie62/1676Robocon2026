// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

package frc.robot.subsystems.swervedrive;

import edu.wpi.first.math.VecBuilder;
import edu.wpi.first.math.controller.SimpleMotorFeedforward;
import edu.wpi.first.math.geometry.Pose2d;
import edu.wpi.first.math.geometry.Pose3d;
import edu.wpi.first.math.geometry.Rotation2d;
import edu.wpi.first.math.geometry.Rotation3d;
import edu.wpi.first.math.geometry.Translation2d;
import edu.wpi.first.math.kinematics.ChassisSpeeds;
import edu.wpi.first.math.kinematics.SwerveDriveKinematics;
import edu.wpi.first.math.trajectory.Trajectory;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj2.command.Command;
import edu.wpi.first.wpilibj2.command.SubsystemBase;
import edu.wpi.first.wpilibj2.command.sysid.SysIdRoutine.Config;
import frc.robot.Constants;

import java.io.File;
import java.util.Arrays;
import java.util.function.DoubleSupplier;
import java.util.function.Supplier;
import com.pathplanner.lib.auto.AutoBuilder;
import com.pathplanner.lib.commands.PathfindingCommand;
import com.pathplanner.lib.controllers.PPHolonomicDriveController;
import com.studica.frc.AHRS;

import java.util.Optional;
import limelight.Limelight;
import swervelib.SwerveController;
import swervelib.SwerveDrive;
import swervelib.SwerveDriveTest;
import swervelib.math.SwerveMath;
import swervelib.parser.SwerveDriveConfiguration;
import swervelib.parser.SwerveParser;
import swervelib.telemetry.SwerveDriveTelemetry;
import swervelib.telemetry.SwerveDriveTelemetry.TelemetryVerbosity;
import limelight.networktables.PoseEstimate;
import limelight.networktables.AngularVelocity3d;
import limelight.networktables.LimelightSettings.ImuMode;
import limelight.networktables.Orientation3d;

import static edu.wpi.first.units.Units.DegreesPerSecond;

public class SwerveSubsystem extends SubsystemBase
{
  private final SwerveDrive swerveDrive;

  private final Limelight limelightLeft, limelightRight, limelightFront;

  private PoseEstimate poseEstimatesLeft, poseEstimatesRight, poseEstimatesFront; 

  private boolean isLocked;

  /**
   * Initialize {@link SwerveDrive} with the directory provided.
   *
   * @param directory Directory of swerve drive config files.
   * @param limelight Limelight camera for vision measurements.
   */

  public SwerveSubsystem(File directory, Limelight limelightLeft, Limelight limelightRight, Limelight limelightFront)
  { 
    this.limelightLeft = limelightLeft; 
    this.limelightRight = limelightRight;
    this.limelightFront = limelightFront;

    setupLimelights();

    poseEstimatesLeft = new PoseEstimate(limelightLeft, "botpose_orb_wpiblue", true);
    poseEstimatesRight = new PoseEstimate(limelightRight, "botpose_orb_wpiblue", true);
    poseEstimatesFront = new PoseEstimate(limelightFront, "botpose_orb_wpiblue", true);

    SwerveDriveTelemetry.verbosity = TelemetryVerbosity.HIGH;

    try {
      swerveDrive = new SwerveParser(directory).createSwerveDrive(Constants.MAX_SPEED, new Pose2d(16.0,4.0, new Rotation2d(0)));
    } catch (Exception e)
    {
      throw new RuntimeException(e);
    }

    swerveDrive.setHeadingCorrection(false); // Heading correction should only be used while controlling the robot via angle.
    swerveDrive.setCosineCompensator(false);//!SwerveDriveTelemetry.isSimulation); // Disables cosine compensation for simulations since it causes discrepancies not seen in real life.
    swerveDrive.setAngularVelocityCompensation(true,
                                               true,
                                               0.1); //Correct for skew that gets worse as angular velocity increases. Start with a coefficient of 0.1.
    swerveDrive.setModuleEncoderAutoSynchronize(true,
                                                0.5); // Enable if you want to resynchronize your absolute encoders and motor encoders periodically when they are not moving.
    zeroGyroWithAlliance();

    Constants.Pathplanner.configurePathplanner(); 
    setupPathplanner();
    
    isLocked = false;
  }
  
  public void setupLimelights() {

    // Left LL4: Forward=-0.190769, Right=-0.28206, Up=0.535823
    // Yaw=-105.915°, Pitch=20°, Roll=0°
    limelightLeft.getSettings()
        .withPipelineIndex(Constants.Limelight.LIMELIGHT_LEFT_PIPELINE_INDEX)
        .withImuMode(ImuMode.ExternalImu)
        .withCameraOffset(new Pose3d(
            -0.190769,
            0.28206,
            0.535823,
            new Rotation3d(
                Math.toRadians(0),
                Math.toRadians(20),
                Math.toRadians(-105.915266))))
        .save();

    // Right LL4: Forward=-0.190769, Right=0.28206, Up=0.535823
    // Yaw=105.915°, Pitch=20°, Roll=0°
    limelightRight.getSettings()
        .withPipelineIndex(Constants.Limelight.LIMELIGHT_RIGHT_PIPELINE_INDEX)
        .withImuMode(ImuMode.ExternalImu)
        .withCameraOffset(new Pose3d(
            -0.190769,
            -0.28206,
            0.535823,
            new Rotation3d(
                Math.toRadians(0),
                Math.toRadians(20),
                Math.toRadians(105.915266))))
        .save();

    // Middle LL3: Forward=-0.330204, Right=0, Up=0.526539
    // Yaw=180°, Pitch=20°, Roll=0°
    limelightFront.getSettings()
        .withPipelineIndex(Constants.Limelight.LIMELIGHT_FRONT_PIPELINE_INDEX)
        .withImuMode(ImuMode.ExternalImu)
        .withCameraOffset(new Pose3d(
            -0.330204,
            0,
            0.526539,
            new Rotation3d(
                Math.toRadians(0),
                Math.toRadians(20),
                Math.toRadians(180))))
        .save();
  }


  @Override
  public void periodic()
  {
    //Add gyro values
    SmartDashboard.putNumber("Raw Yaw", getRawGyroYaw().getDegrees());
    SmartDashboard.putNumber("Raw Pitch", getRawGyroPitch().getDegrees());
    SmartDashboard.putNumber("Raw Roll", getRawGyroRoll().getDegrees());

    // Add telemetry for front-left module
    // SmartDashboard.putNumber("FL Angle", swerveDrive.getModules()[0].getAbsolutePosition());
    // SmartDashboard.putNumber("FR Angle", swerveDrive.getModules()[1].getAbsolutePosition());
    // SmartDashboard.putNumber("BL Angle", swerveDrive.getModules()[2].getAbsolutePosition());
    // SmartDashboard.putNumber("BR Angle", swerveDrive.getModules()[3].getAbsolutePosition());
    // SmartDashboard.putNumber("Robot Heading", getHeading().getDegrees());

    SmartDashboard.putNumber("FL Speed", swerveDrive.getModules()[0].getMaxDriveVelocityMetersPerSecond());
    SmartDashboard.putNumber("FR Speed", swerveDrive.getModules()[1].getMaxDriveVelocityMetersPerSecond());
    SmartDashboard.putNumber("BL Speed", swerveDrive.getModules()[2].getMaxDriveVelocityMetersPerSecond());
    SmartDashboard.putNumber("BR Speed", swerveDrive.getModules()[3].getMaxDriveVelocityMetersPerSecond());

    updateLimelight(limelightFront); 
    updateLimelight(limelightLeft);
    updateLimelight(limelightRight);

    // Update odometry with Limelight vision measurements
    updatePoseFromLimelight();    

    // Consolidated telemetry - reduced SmartDashboard calls to minimize loop overrun
    SmartDashboard.putString("Robot Odometry from limelight", 
      String.format("X:%.2f Y:%.2f R:%.1f", 
        getPose().getX(), 
        getPose().getY(), 
        getPose().getRotation().getDegrees())
    );

    //distance from hub
    double deltaX = getPose().getX() - Constants.Hub.getTargetX();
    double deltaY = getPose().getY() - Constants.Hub.TARGET_Y;

    double distance = Math.sqrt(deltaX * deltaX + deltaY * deltaY);

    SmartDashboard.putNumber("Distance", distance);

    SmartDashboard.putBoolean("Wheels Locked", isLocked);

  }

  public void setupPathplanner () {
    final boolean enableFeedForward = true; 

    AutoBuilder.configure(
      this::getPose, 
      this::resetOdometry, 
      this::getRobotVelocity, 
      (speedsRobotRelative, moduleFeedForwards) -> {
        if(enableFeedForward) {
          swerveDrive.drive(
            speedsRobotRelative,
            swerveDrive.kinematics.toSwerveModuleStates(speedsRobotRelative),
            moduleFeedForwards.linearForces()
          );  
        } else {
          swerveDrive.setChassisSpeeds(speedsRobotRelative);
        }
      }, 
      new PPHolonomicDriveController(
        Constants.Pathplanner.TRANSLATIONAL_PID,
        Constants.Pathplanner.ROTATIONAL_PID
      ),
      Constants.Pathplanner.PATHPLANNER_ROBOT_CONFIG, // ROBOT Config for pathplanner 
      () -> {
        return Constants.Alliance.RED();
        //red alliance will have everything mirrored. Origin remains on blue side
      },
      this // reference to this subsystem to set requirements
    );

    PathfindingCommand.warmupCommand().schedule();

  }

  /**
   * Updates the odometry with pose estimates from both Limelight cameras.
   * Fuses data from left and right cameras for robust vision-based localization.
   */
  
  public void updatePoseFromLimelight() {
    if(limelightLeft != null)
      updateVisionFromCamera(limelightLeft, Constants.Limelight.LIMELIGHT_LEFT_NAME, poseEstimatesLeft);
    if(limelightRight != null)
      updateVisionFromCamera(limelightRight, Constants.Limelight.LIMELIGHT_RIGHT_NAME, poseEstimatesRight);
    if(limelightFront != null)
      updateVisionFromCamera(limelightFront, Constants.Limelight.LIMELIGHT_FRONT_NAME, poseEstimatesFront);
  }

  /**
   * Helper method to update vision from a single Limelight camera.
   * 
   * @param limelight The Limelight camera to read from
   * @param cameraName Name of the camera for telemetry
   * @param estimator The pose estimator for this camera
   */
  private void updateVisionFromCamera(Limelight limelight, String cameraName, PoseEstimate poseEstimates) {
    Optional<PoseEstimate> poseEstimator = poseEstimates.getPoseEstimate(); 

    boolean isPresent = poseEstimator.isPresent();
    SmartDashboard.putBoolean(cameraName + " Results Present?", isPresent);

    if(isPresent) {
      PoseEstimate poseEstimate = poseEstimator.get();
      boolean isValid = poseEstimate.tagCount > 0;
      SmartDashboard.putBoolean(cameraName + " Results Valid?", isValid);

    if(poseEstimate.tagCount == 0) {
      SmartDashboard.putBoolean(cameraName + " Tracking?", false);
      return;
    }

    //TUNING AND ADJUSTING NEEDED HERE ////////////////////
    double stdDevXY = 0.5; //default

    if(poseEstimate.tagCount >= 2) {
        stdDevXY = 0.2;  // multiple tags means we can trust readings more
    } else if(poseEstimate.avgTagDist < 2.0) {
        stdDevXY = 0.3;  //single tag but close distance
    }
    /////////////////////////////////////////////////////////

    swerveDrive.setVisionMeasurementStdDevs(VecBuilder.fill(stdDevXY, stdDevXY, 99999));
    swerveDrive.addVisionMeasurement(
        poseEstimate.pose.toPose2d(),
        poseEstimate.timestampSeconds
    );
    SmartDashboard.putBoolean(cameraName + " Tracking?", true);

    }
  }

    public void updateLimelight(Limelight limelight) {

    //update limelight orientation/yaw with gyro data from swerve drivrbase 

     limelight.getSettings()
        .withRobotOrientation(new Orientation3d(
            new Rotation3d(
                getRawGyroRoll().getRadians(),
                -getRawGyroPitch().getRadians(),
                getRawGyroYaw().getRadians()
            ),
            new AngularVelocity3d(
                DegreesPerSecond.of(getRollRate()),
                DegreesPerSecond.of(-getPitchRate()),
                DegreesPerSecond.of(Math.toDegrees(getRobotVelocity().omegaRadiansPerSecond))
            )
        ))
        .save();
        
  }

  /** 
   * Command to characterize the robot drive motors using SysId
   *
   * @return SysId Drive Command
   */
  public Command sysIdDriveMotorCommand()
  {
    return SwerveDriveTest.generateSysIdCommand(
        SwerveDriveTest.setDriveSysIdRoutine(
            new Config(),
            this, swerveDrive, 12, true),
        3.0, 5.0, 3.0);
  }

  /**
   * Command to characterize the robot angle motors using SysId
   *
   * @return SysId Angle Command
   */
  public Command sysIdAngleMotorCommand()
  {
    return SwerveDriveTest.generateSysIdCommand(
        SwerveDriveTest.setAngleSysIdRoutine(
            new Config(),
            this, swerveDrive),
        3.0, 5.0, 3.0);
  }

  /**
   * Returns a Command that centers the modules of the SwerveDrive subsystem.
   *
   * @return a Command that centers the modules of the SwerveDrive subsystem
   */
  public Command centerModulesCommand()
  {
    return run(() -> Arrays.asList(swerveDrive.getModules())
                           .forEach(it -> it.setAngle(0.0)));
  }

  /**
   * Returns a Command that tells the robot to drive forward until the command ends.
   *
   * @return a Command that tells the robot to drive forward until the command ends
   */
  public Command driveForward()
  {
    return run(() -> {
      swerveDrive.drive(new Translation2d(1, 0), 0, false, false);
    }).finallyDo(() -> swerveDrive.drive(new Translation2d(0, 0), 0, false, false));
  }


  /**
   * Replaces the swerve module feedforward with a new SimpleMotorFeedforward object.
   *
   * @param kS the static gain of the feedforward
   * @param kV the velocity gain of the feedforward
   * @param kA the acceleration gain of the feedforward
   */
  public void replaceSwerveModuleFeedforward(double kS, double kV, double kA)
  {
    swerveDrive.replaceSwerveModuleFeedforward(new SimpleMotorFeedforward(kS, kV, kA));
  }

  /**
   * Command to drive the robot using translative values and heading as angular velocity.
   *
   * @param translationX     Translation in the X direction. Cubed for smoother controls.
   * @param translationY     Translation in the Y direction. Cubed for smoother controls.
   * @param angularRotationX Angular velocity of the robot to set. Cubed for smoother controls.
   * @return Drive command.
   */
  public Command driveCommand(DoubleSupplier translationX, DoubleSupplier translationY, DoubleSupplier angularRotationX)
  {
    return run(() -> {
      // Make the robot move
      swerveDrive.drive(SwerveMath.scaleTranslation(new Translation2d(
                            translationX.getAsDouble() * swerveDrive.getMaximumChassisVelocity(),
                            translationY.getAsDouble() * swerveDrive.getMaximumChassisVelocity()), 0.8),
                        Math.pow(angularRotationX.getAsDouble(), 3) * swerveDrive.getMaximumChassisAngularVelocity(),
                        true,
                        false);
    });
  }

  /**
   * Command to drive the robot using translative values and heading as a setpoint.
   *
   * @param translationX Translation in the X direction. Cubed for smoother controls.
   * @param translationY Translation in the Y direction. Cubed for smoother controls.
   * @param headingX     Heading X to calculate angle of the joystick.
   * @param headingY     Heading Y to calculate angle of the joystick.
   * @return Drive command.
   */
  public Command driveCommand(DoubleSupplier translationX, DoubleSupplier translationY, DoubleSupplier headingX,
                              DoubleSupplier headingY)
  {
    swerveDrive.setHeadingCorrection(true); // Normally you would want heading correction for this kind of control.
    return run(() -> {

      Translation2d scaledInputs = SwerveMath.scaleTranslation(new Translation2d(translationX.getAsDouble(),
                                                                                 translationY.getAsDouble()), 0.8);

      // Make the robot move
      driveFieldOriented(swerveDrive.swerveController.getTargetSpeeds(scaledInputs.getX(), scaledInputs.getY(),
                                                                      headingX.getAsDouble(),
                                                                      headingY.getAsDouble(),
                                                                      swerveDrive.getOdometryHeading().getRadians(),
                                                                      swerveDrive.getMaximumChassisVelocity()));
    });
  }

  /**
   * The primary method for controlling the drivebase.  Takes a {@link Translation2d} and a rotation rate, and
   * calculates and commands module states accordingly.  Can use either open-loop or closed-loop velocity control for
   * the wheel velocities.  Also has field- and robot-relative modes, which affect how the translation vector is used.
   *
   * @param translation   {@link Translation2d} that is the commanded linear velocity of the robot, in meters per
   *                      second. In robot-relative mode, positive x is torwards the bow (front) and positive y is
   *                      torwards port (left).  In field-relative mode, positive x is away from the alliance wall
   *                      (field North) and positive y is torwards the left wall when looking through the driver station
   *                      glass (field West).
   * @param rotation      Robot angular rate, in radians per second. CCW positive.  Unaffected by field/robot
   *                      relativity.
   * @param fieldRelative Drive mode.  True for field-relative, false for robot-relative.
   */
  public void drive(Translation2d translation, double rotation, boolean fieldRelative)
  {
    swerveDrive.drive(translation,
                      rotation,
                      fieldRelative,
                      false); // Open loop is disabled since it shouldn't be used most of the time.
  }

  /**
   * Drive the robot given a chassis field oriented velocity.
   *
   * @param velocity Velocity according to the field.
   */
  public void driveFieldOriented(ChassisSpeeds velocity)
  {
    swerveDrive.driveFieldOriented(velocity);
  }

  /**
   * Drive the robot given a chassis field oriented velocity.
   *
   * @param velocity Velocity according to the field.
   */
  public Command driveFieldOriented(Supplier<ChassisSpeeds> velocity)
  {
    return run(() -> {
      swerveDrive.driveFieldOriented(velocity.get());
    });
  }

  /**
   * Drive according to the chassis robot oriented velocity.
   *
   * @param velocity Robot oriented {@link ChassisSpeeds}
   */
  public void drive(ChassisSpeeds velocity)
  {
    swerveDrive.drive(velocity);
  
  
  }

  public Rotation2d getRawGyroYaw(){
    return swerveDrive.getYaw(); 
  }

  public Rotation2d getRawGyroRoll(){
    return swerveDrive.getRoll(); 
  }

  public Rotation2d getRawGyroPitch(){
    return swerveDrive.getPitch(); 
  }

  /**
   * Get the swerve drive kinematics object.
   *
   * @return {@link SwerveDriveKinematics} of the swerve drive.
   */
  public SwerveDriveKinematics getKinematics()
  {
    return swerveDrive.kinematics;
  }

  /**
   * Resets odometry to the given pose. Gyro angle and module positions do not need to be reset when calling this
   * method.  However, if either gyro angle or module position is reset, this must be called in order for odometry to
   * keep working.
   *
   * @param initialHolonomicPose The pose to set the odometry to
   */
  public void resetOdometry(Pose2d initialHolonomicPose)
  {
    swerveDrive.resetOdometry(initialHolonomicPose);
  }

  /**
   * Gets the current pose (position and rotation) of the robot, as reported by odometry.
   *
   * @return The robot's pose
   */
  public Pose2d getPose()
  {
    return swerveDrive.getPose();
  }

    public double getDistance (double TARGET_X, double TARGET_Y){
    double deltaX = Math.abs(TARGET_X - getPose().getX());
    double deltaY = Math.abs(TARGET_Y - getPose().getY());

    return Math.sqrt(deltaX * deltaX + deltaY * deltaY);
  }

  /**
   * Set chassis speeds with closed-loop velocity control.
   *
   * @param chassisSpeeds Chassis Speeds to set.
   */
  public void setChassisSpeeds(ChassisSpeeds chassisSpeeds)
  {
    swerveDrive.setChassisSpeeds(chassisSpeeds);
  }

  /**
   * Post the trajectory to the field.
   *
   * @param trajectory The trajectory to post.
   */
  public void postTrajectory(Trajectory trajectory)
  {
    swerveDrive.postTrajectory(trajectory);
  }

  /**
   * Resets the gyro angle to zero and resets odometry to the same position, but facing toward 0.
   */
  public void zeroGyro()
  {
    swerveDrive.zeroGyro();
  }

  public void setGyro (double offset) { 

    swerveDrive.setGyro(new Rotation3d(0,0, Math.toRadians(offset)));

  }

  /**
   * This will zero (calibrate) the robot to assume the current position is facing forward
   * <p>
   * If red alliance rotate the robot 180 after the drviebase zero command
   */
  public void zeroGyroWithAlliance()
  {
    if (Constants.Alliance.RED())
    {
      setGyro(180);
      resetOdometry(new Pose2d(getPose().getTranslation(), Rotation2d.fromDegrees(180)));
    } else
    {
      setGyro(0);
      resetOdometry(new Pose2d(getPose().getTranslation(), Rotation2d.fromDegrees(0)));
    }
  }

  public void setHeadingCorrection (boolean b) { 
    swerveDrive.setHeadingCorrection(b);
  }

  /**
   * Sets the drive motors to brake/coast mode.
   *
   * @param brake True to set motors to brake mode, false for coast.
   */
  public void setMotorBrake(boolean brake)
  {
    swerveDrive.setMotorIdleMode(brake);
  }

  /**
   * Gets the current yaw angle of the robot, as reported by the swerve pose estimator in the underlying drivebase.
   * Note, this is not the raw gyro reading, this may be corrected from calls to resetOdometry().
   *
   * @return The yaw angle
   */
  public Rotation2d getHeading()
  {
    return getPose().getRotation();
  }

  /**
   * Get the chassis speeds based on controller input of 2 joysticks. One for speeds in which direction. The other for
   * the angle of the robot.
   *
   * @param xInput   X joystick input for the robot to move in the X direction.
   * @param yInput   Y joystick input for the robot to move in the Y direction.
   * @param headingX X joystick which controls the angle of the robot.
   * @param headingY Y joystick which controls the angle of the robot.
   * @return {@link ChassisSpeeds} which can be sent to the Swerve Drive.
   */
  public ChassisSpeeds getTargetSpeeds(double xInput, double yInput, double headingX, double headingY)
  {
    Translation2d scaledInputs = SwerveMath.cubeTranslation(new Translation2d(xInput, yInput));
    return swerveDrive.swerveController.getTargetSpeeds(scaledInputs.getX(),
                                                        scaledInputs.getY(),
                                                        headingX,
                                                        headingY,
                                                        getHeading().getRadians(),
                                                        Constants.MAX_SPEED);
  }

  /**
   * Get the chassis speeds based on controller input of 1 joystick and one angle. Control the robot at an offset of
   * 90deg.
   *
   * @param xInput X joystick input for the robot to move in the X direction.
   * @param yInput Y joystick input for the robot to move in the Y direction.
   * @param angle  The angle in as a {@link Rotation2d}.
   * @return {@link ChassisSpeeds} which can be sent to the Swerve Drive.
   */
  public ChassisSpeeds getTargetSpeeds(double xInput, double yInput, Rotation2d angle)
  {
    Translation2d scaledInputs = SwerveMath.cubeTranslation(new Translation2d(xInput, yInput));

    return swerveDrive.swerveController.getTargetSpeeds(scaledInputs.getX(),
                                                        scaledInputs.getY(),
                                                        angle.getRadians(),
                                                        getHeading().getRadians(),
                                                        Constants.MAX_SPEED);
  }

  /**
   * Gets the current field-relative velocity (x, y and omega) of the robot
   *
   * @return A ChassisSpeeds object of the current field-relative velocity
   */
  public ChassisSpeeds getFieldVelocity()
  {
    return swerveDrive.getFieldVelocity();
  }

  /**
   * Gets the current velocity (x, y and omega) of the robot
   *
   * @return A {@link ChassisSpeeds} object of the current velocity
   */
  public ChassisSpeeds getRobotVelocity()
  {
    return swerveDrive.getRobotVelocity();
  }

  /**
   * Get the {@link SwerveController} in the swerve drive.
   *
   * @return {@link SwerveController} from the {@link SwerveDrive}.
   */
  public SwerveController getSwerveController()
  {
    return swerveDrive.swerveController;
  }

  /**
   * Get the {@link SwerveDriveConfiguration} object.
   *
   * @return The {@link SwerveDriveConfiguration} fpr the current drive.
   */
  public SwerveDriveConfiguration getSwerveDriveConfiguration()
  {
    return swerveDrive.swerveDriveConfiguration;
  }

  /**
   * Lock the swerve drive to prevent it from moving.
   */
  public void lock()
  {
    swerveDrive.lockPose();
  }

  public void setIsLocked(boolean val) {
    isLocked = val;
  }

  public boolean getIsLocked() {
    return isLocked;
  }
/**
 * switches swerve between brake and coast modes
 * @param b
 * if b is true, sets swerve to brake mode
 * if b is false, sets swerve to coast mode
 */
  public void setMode(boolean b) {
    swerveDrive.setMotorIdleMode(b);
  }

  /**
   * Gets the current pitch angle of the robot, as reported by the imu.
   *
   * @return The heading as a {@link Rotation2d} angle
   */
  public Rotation2d getPitch()
  {
    return swerveDrive.getPitch();
  }

  public double getPitchRate() {
    return ((AHRS) swerveDrive.getGyro().getIMU()).getRawGyroX(); 
  }

  public double getRollRate() {
    return ((AHRS) swerveDrive.getGyro().getIMU()).getRawGyroY(); 
  }

  /**
   * Gets the swerve drive object.
   *
   * @return {@link SwerveDrive}
   */
  public SwerveDrive getSwerveDrive()
  {
    return swerveDrive;
  }

}
