package frc.robot.subsystems;


import com.revrobotics.spark.SparkBase.ControlType;
import com.revrobotics.spark.SparkFlex;
import com.revrobotics.spark.SparkClosedLoopController;
import com.revrobotics.spark.config.SparkBaseConfig.IdleMode;
import com.revrobotics.spark.config.SparkFlexConfig;
import com.revrobotics.PersistMode;
import com.revrobotics.RelativeEncoder;
import com.revrobotics.ResetMode;

import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj2.command.SubsystemBase;
import frc.robot.Constants;

public class Shooter extends SubsystemBase {
    private SparkFlex shooterMotorTopRight;
    private SparkFlex shooterMotorBottomRight;
    private SparkFlex shooterMotorTopLeft;
    private SparkFlex shooterMotorBottomLeft;
    private SparkClosedLoopController pidController;
    private RelativeEncoder encoder;

    public Shooter(int MOTOR_ID1, int MOTOR_ID2, int MOTOR_ID3, int MOTOR_ID4) {
        
        shooterMotorTopRight = new SparkFlex(MOTOR_ID1, SparkFlex.MotorType.kBrushless);
        shooterMotorBottomRight = new SparkFlex(MOTOR_ID2, SparkFlex.MotorType.kBrushless);
        shooterMotorTopLeft = new SparkFlex(MOTOR_ID3, SparkFlex.MotorType.kBrushless);
        shooterMotorBottomLeft = new SparkFlex(MOTOR_ID4, SparkFlex.MotorType.kBrushless);

        SparkFlexConfig configTopR = new SparkFlexConfig();
        SparkFlexConfig configBottomR = new SparkFlexConfig();
        SparkFlexConfig configTopL = new SparkFlexConfig();
        SparkFlexConfig configBottomL = new SparkFlexConfig(); 

        configTopR
            // Configure ramp rate for smooth acceleration (in seconds)
            .closedLoopRampRate(Constants.Shooter.RAMP_TIME)
            // Configure idle mode
            .idleMode(IdleMode.kCoast);
        
        // Configure PID gains for velocity control
        configTopR.closedLoop.pid (
            Constants.Shooter.kP,
            Constants.Shooter.kI,
            Constants.Shooter.kD
        );
        configBottomR.follow(MOTOR_ID1, false); 
        configTopL.follow(MOTOR_ID1, true); 
        configBottomL.follow(MOTOR_ID1, true); 

        
        shooterMotorTopRight.configure(configTopR, ResetMode.kResetSafeParameters, PersistMode.kPersistParameters);
        shooterMotorBottomRight.configure(configBottomR, ResetMode.kResetSafeParameters, PersistMode.kPersistParameters);
        shooterMotorTopLeft.configure(configTopL, ResetMode.kResetSafeParameters, PersistMode.kPersistParameters);
        shooterMotorBottomLeft.configure(configBottomL, ResetMode.kResetSafeParameters, PersistMode.kPersistParameters);
    
        // Get controller and encoder references from leader motor
        pidController = shooterMotorTopRight.getClosedLoopController();
        encoder = shooterMotorTopRight.getEncoder();
    }

    public void setShooterSpeed(double rpm) {
        // Set velocity setpoint in RPM
        pidController.setSetpoint(rpm, ControlType.kVelocity);
    }

    public double getRPM() {
        return encoder.getVelocity();
    }

    public double getTopLeftEncoder() {
        return shooterMotorTopLeft.getEncoder().getVelocity();
    }

    public double getTopRightEncoder() {
        return shooterMotorTopRight.getEncoder().getVelocity();
    }

    public double getBottomLeftEncoder() {
        return shooterMotorBottomLeft.getEncoder().getVelocity();
    }

    public double getBottomRightEncoder() {
        return shooterMotorBottomRight.getEncoder().getVelocity();
    }

    public void stop() {
        shooterMotorTopRight.stopMotor();
        shooterMotorBottomRight.stopMotor();
        shooterMotorTopLeft.stopMotor();
        shooterMotorBottomLeft.stopMotor();
    }

    @Override
    public void periodic () {
        SmartDashboard.putNumber("shooter RPM", getRPM());

        //Encoder Values
        // SmartDashboard.putNumber("Top Right Encoder Val", getTopRightEncoder());
        // SmartDashboard.putNumber("Top Left Encoder Val", getTopLeftEncoder());
        // SmartDashboard.putNumber("Bottom Right Encoder Val", getBottomRightEncoder());
        // SmartDashboard.putNumber("Bottom Left Encoder Val", getBottomLeftEncoder());
        SmartDashboard.putNumber("shooter setpoint", pidController.getSetpoint());
    }
}
