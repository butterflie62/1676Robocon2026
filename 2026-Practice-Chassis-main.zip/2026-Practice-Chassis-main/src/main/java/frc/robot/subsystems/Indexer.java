package frc.robot.subsystems;

import com.ctre.phoenix6.configs.TalonFXConfiguration;
import com.ctre.phoenix6.hardware.TalonFX;
import com.ctre.phoenix6.signals.NeutralModeValue;

import edu.wpi.first.wpilibj2.command.SubsystemBase;
import frc.robot.Constants;

public class Indexer extends SubsystemBase {

    private TalonFX indexer; 
    private TalonFXConfiguration config; 
    
    public Indexer (int MOTOR_ID) {
        indexer = new TalonFX(MOTOR_ID); 

        config = new TalonFXConfiguration(); 
        config.MotorOutput.NeutralMode = NeutralModeValue.Coast;
        config.OpenLoopRamps.DutyCycleOpenLoopRampPeriod = Constants.Indexer.RAMP_TIME;  
        config.CurrentLimits.SupplyCurrentLimit = Constants.Indexer.CURRENT_LIMIT;
        config.CurrentLimits.SupplyCurrentLimitEnable = true;

        indexer.getConfigurator().apply(config); 
    }

    public void setSpeed (double speed) {
        indexer.set(speed);
    }
    
    
    public double getSpeed() {
        return indexer.get();
    }

    public void stop() {
        indexer.stopMotor();
    }

}
