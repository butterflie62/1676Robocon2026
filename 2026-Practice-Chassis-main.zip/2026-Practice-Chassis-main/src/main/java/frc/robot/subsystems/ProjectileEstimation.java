package frc.robot.subsystems;

import edu.wpi.first.math.geometry.Rotation2d;
import edu.wpi.first.math.geometry.Translation2d;
import edu.wpi.first.math.interpolation.InterpolatingDoubleTreeMap;
import edu.wpi.first.math.kinematics.ChassisSpeeds;
import edu.wpi.first.wpilibj2.command.SubsystemBase;
import frc.robot.Constants;
import frc.robot.subsystems.swervedrive.SwerveSubsystem;

public class ProjectileEstimation extends SubsystemBase {

    private InterpolatingDoubleTreeMap TOF = Constants.Shooter.TOF;
    private InterpolatingDoubleTreeMap RPM = Constants.Shooter.RPM;
    private InterpolatingDoubleTreeMap HoodAngle = Constants.Shooter.HOOD_ANGLE;
    private SwerveSubsystem swerve; 

    public ProjectileEstimation (SwerveSubsystem swerve) {
        this.swerve = swerve; 

        Constants.Shooter.setUpTOF();
        Constants.Shooter.setUpRPM();
        Constants.Shooter.setUpHoodAngle(); 
    }

    public double getTOF(double TARGET_X, double TARGET_Y) {
        return TOF.get(getDistance(TARGET_X, TARGET_Y));
    }

    public double getRPM(double TARGET_X, double TARGET_Y) {
        return RPM.get(getDistanceAdjusted(TARGET_X, TARGET_Y));
    }

    public double getHoodAngle(double TARGET_X, double TARGET_Y) {
        return HoodAngle.get(getDistanceAdjusted(TARGET_X, TARGET_Y));
    }

    public double getDistanceAdjusted (double TARGET_X, double TARGET_Y) { 
        Translation2d futurePosition = getFuturePosition(TARGET_X, TARGET_Y);

        double deltaX = Math.abs (futurePosition.getX() - TARGET_X);
        double deltaY = Math.abs (futurePosition.getY() - TARGET_Y); 

        return Math.sqrt (deltaX * deltaX + deltaY * deltaY); 
    }

    public Translation2d getFuturePosition (double TARGET_X, double TARGET_Y) { 

        Translation2d currentPosition = swerve.getPose().getTranslation(); 
        ChassisSpeeds currenSpeeds = swerve.getFieldVelocity(); 
        Translation2d currentVelocityVector = new Translation2d(
            currenSpeeds.vxMetersPerSecond,
            currenSpeeds.vyMetersPerSecond
        ); 

        Translation2d predictedTranslation = new Translation2d( 
            currentVelocityVector.getX() * getTOF(TARGET_X, TARGET_Y),
            currentVelocityVector.getY() * getTOF(TARGET_X, TARGET_Y)
        ); 

        return currentPosition.plus(predictedTranslation); 
    }

    public Rotation2d calculateAdjustedAngleToTarget (double TARGET_X, double TARGET_Y) {
        
        Translation2d futurePosition = getFuturePosition(TARGET_X, TARGET_Y);
        // Calculate the vector from robot to target
        double deltaX = TARGET_X - futurePosition.getX();
        double deltaY = TARGET_Y - futurePosition.getY();

        // Calculate the angle using atan2
        return new Rotation2d(Math.atan2(deltaY, deltaX));
    }

    public Rotation2d calculateAngleToTarget(Translation2d position, double targetX, double targetY) {
        // Calculate the vector from robot to target
        double deltaX = targetX - position.getX();
        double deltaY = targetY - position.getY();
        
        // Calculate the angle using atan2
        return new Rotation2d(Math.atan2(deltaY, deltaX));
    }

    public double getDistance (double TARGET_X, double TARGET_Y) {
        double deltaX = Math.abs (TARGET_X - swerve.getPose().getX()); 
        double deltaY = Math.abs (TARGET_Y - swerve.getPose().getY());

        return Math.sqrt(deltaX * deltaX + deltaY * deltaY); 
    }


}