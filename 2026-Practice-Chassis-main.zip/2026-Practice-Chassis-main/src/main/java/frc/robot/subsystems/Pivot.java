package frc.robot.subsystems;

import static edu.wpi.first.units.Units.Volts;

import com.ctre.phoenix6.SignalLogger;
import com.ctre.phoenix6.configs.TalonFXConfiguration;
import com.ctre.phoenix6.controls.MotionMagicVoltage;
import com.ctre.phoenix6.controls.VoltageOut;
import com.ctre.phoenix6.hardware.TalonFX;
import com.ctre.phoenix6.signals.GravityTypeValue;
import com.ctre.phoenix6.signals.NeutralModeValue;

import edu.wpi.first.units.measure.Voltage;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj2.command.Command;
import edu.wpi.first.wpilibj2.command.SubsystemBase;
import edu.wpi.first.wpilibj2.command.sysid.SysIdRoutine;
import frc.robot.Constants;

//check over the following code

public class Pivot extends SubsystemBase {
    
    private TalonFX pivot;
    private double setpoint;
    private MotionMagicVoltage request;
    private SysIdRoutine routine;
    private VoltageOut vRequest = new VoltageOut(0);
    
    public Pivot(int MOTOR_ID) {
        pivot = new TalonFX(MOTOR_ID);
        TalonFXConfiguration config = new TalonFXConfiguration();

        config.MotorOutput.NeutralMode = NeutralModeValue.Brake;
        config.MotionMagic.MotionMagicAcceleration = Constants.Pivot.MAX_ACCELERATION; 
        config.MotionMagic.MotionMagicCruiseVelocity = Constants.Pivot.MAX_SPEED; 
        config.MotionMagic.MotionMagicJerk = Constants.Pivot.MAX_JERK; 

        config.Slot0.kV = Constants.Pivot.kV;
        config.Slot0.kS = Constants.Pivot.kS;
        config.Slot0.kA = Constants.Pivot.kA;
        config.Slot0.kP = Constants.Pivot.kP;
        config.Slot0.kI = Constants.Pivot.kI;
        config.Slot0.kD = Constants.Pivot.kD;
        config.Slot0.kG = Constants.Pivot.kG; 
        config.Slot0.GravityType = GravityTypeValue.Arm_Cosine; 

        pivot.getConfigurator().apply(config);
        
        // create a position closed-loop request, voltage output, slot 0 configs
        setpoint = Constants.Pivot.STOWED_POSITION; 
        request = new MotionMagicVoltage(setpoint); //directly controls output voltage      
        
        routine = new SysIdRoutine(
            new SysIdRoutine.Config(
                null,
                Volts.of(4),
                null,
                state ->  {
                    System.out.println(SignalLogger.writeString("state", state.toString()));
                }
            ), 
            new SysIdRoutine.Mechanism(
                volts -> pivot.setControl(vRequest.withOutput(volts.in(Volts))), 
                null, 
                this));
    }

    public void setSpeed(double speed) {
       pivot.set(speed);
    }

    public double getSpeed() {
        return pivot.get();
    }

    public double getPosition() {
        return pivot.getPosition().getValueAsDouble();
    }

    public double getSetpoint() {
        return setpoint;
    }

    /* *
     * Changes the setpoint to the given position
     * Makes the motor go to the new setpoint
     */
    public void setPosition(double position) {
        setpoint = position; 
        pivot.setControl(request.withPosition(position)); //Changes the position from the current value to the new value
    }

    /* *
     * Checks if the position of the intake matches the current setpoint
     */

    public boolean isAtSetpoint() {
        double pos = getPosition();
        return Math.abs(setpoint - pos) < 0.5;
    }

    public void voltageDrive(Voltage voltage) {
        pivot.setVoltage(voltage.magnitude());
    }

    public void stop() {
        pivot.stopMotor();
    }

    public void periodic() {

        SmartDashboard.putNumber("pivot setpoint", getPosition());
        SmartDashboard.putNumber("pivot velocity", pivot.getVelocity().getValueAsDouble());
    }

    public Command sysIdQuasiStatic(SysIdRoutine.Direction dir) {
        return routine.quasistatic(dir);
    }

    public Command sysIdDynamic(SysIdRoutine.Direction dir) {
        return routine.dynamic(dir);
    }
}
