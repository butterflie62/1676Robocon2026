package frc.robot.subsystems;
import com.ctre.phoenix6.configs.TalonFXConfiguration;
import com.ctre.phoenix6.hardware.TalonFX;
import com.ctre.phoenix6.signals.NeutralModeValue;

import edu.wpi.first.wpilibj2.command.SubsystemBase;

public class Kicker extends SubsystemBase {
    private final TalonFX kicker;
    private final TalonFXConfiguration config;
 
    public Kicker (int MOTOR_ID) {

        kicker = new TalonFX (MOTOR_ID); 

        config = new TalonFXConfiguration(); 
        config.MotorOutput.NeutralMode = NeutralModeValue.Coast; 

        kicker.getConfigurator().apply(config); 

    }

    public void setKickerSpeed(double power) {
        // Set VOLTAGE/POWER setpoint from -1 to 1 
        kicker.set(power);
    }

    public double getSpeed() {
        return kicker.get(); 
    }

    public void stop() {
        kicker.stopMotor();
    }
}
