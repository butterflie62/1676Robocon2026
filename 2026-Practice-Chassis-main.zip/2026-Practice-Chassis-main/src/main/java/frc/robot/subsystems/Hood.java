
package frc.robot.subsystems;

import com.revrobotics.AbsoluteEncoder;
import com.revrobotics.PersistMode;
import com.revrobotics.ResetMode;
import com.revrobotics.spark.FeedbackSensor;
import com.revrobotics.spark.SparkFlex;
import com.revrobotics.spark.SparkBase.ControlType;
import com.revrobotics.spark.SparkLowLevel.MotorType;
import com.revrobotics.spark.config.SparkFlexConfig;
import com.revrobotics.spark.config.SparkBaseConfig.IdleMode;

import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj2.command.SubsystemBase;
import frc.robot.Constants;

//check over the following code

public class Hood extends SubsystemBase {
    
    private SparkFlex hood;
    private AbsoluteEncoder encoder;
        
    public Hood (int MOTOR_ID) {

        hood = new SparkFlex(MOTOR_ID, MotorType.kBrushless);
        encoder = hood.getAbsoluteEncoder();
        
        SparkFlexConfig config = new SparkFlexConfig();
        config.idleMode(IdleMode.kBrake);
        config.closedLoop.pid (
            Constants.Hood.kP,
            Constants.Hood.kI,
            Constants.Hood.kD
        ).feedbackSensor(FeedbackSensor.kAbsoluteEncoder);

        hood.configure(config, ResetMode.kResetSafeParameters, PersistMode.kPersistParameters);
    }

    
    /* *
     * Changes the setpoint to the given position
     * Makes the motor go to the new setpoint
     */
    public void setPose(double position) {//Not ready for use, need to actually make motor go to position
        if(position < Constants.Hood.MAX_POSITION && position > Constants.Hood.MIN_POSITION)
            hood.getClosedLoopController().setSetpoint(position, ControlType.kPosition);
    }

    public void setSpeed(double speed) {
        hood.set(speed);
              
    }

    public double getSpeed() {
        return hood.get();
    }

    public double getPose() {
        return encoder.getPosition();
    }

    public void setEncoder(double position) {
       //not applicable with absolute encoder
    }

    public void stop() {
        hood.stopMotor();
    }

    public void periodic() {
        SmartDashboard.putNumber("Hood position:", getPose());
    }
}
