// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

package frc.robot;

import edu.wpi.first.wpilibj.DriverStation;
import edu.wpi.first.wpilibj.Filesystem;
import edu.wpi.first.wpilibj.smartdashboard.SendableChooser;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj2.command.Command;
import edu.wpi.first.wpilibj2.command.Commands;
import edu.wpi.first.wpilibj2.command.button.CommandXboxController;
import edu.wpi.first.wpilibj2.command.button.Trigger;
import frc.robot.Constants.OperatorConstants;
import frc.robot.commands.AdjustedAlignTo;
import frc.robot.commands.AdjustedSpinShooter;
import frc.robot.commands.Agitate;
import frc.robot.commands.AgitateFurther;
import frc.robot.commands.CollectShooterData;
import frc.robot.commands.ControlHood;
import frc.robot.commands.ControlPivot;
import frc.robot.commands.PivotGoTo;
import frc.robot.commands.PrepareShooter;
import frc.robot.commands.Shoot;
import frc.robot.commands.SpinIntake;
import frc.robot.commands.SpinKicker;
import frc.robot.commands.SwerveAlignToPass;
import frc.robot.commands.swervedrive.drivebase.AbsoluteDrive;
import frc.robot.commands.FeedShooter;
import frc.robot.commands.LockSwerve;
import frc.robot.commands.Pass;
import frc.robot.commands.SpinIndexer;
import frc.robot.subsystems.swervedrive.SwerveSubsystem;
import limelight.Limelight;
import frc.robot.subsystems.Indexer;
import frc.robot.subsystems.Intake;
import frc.robot.subsystems.Hood;
import frc.robot.subsystems.Kicker;
import frc.robot.subsystems.Pivot;
import frc.robot.subsystems.ProjectileEstimation;
import frc.robot.subsystems.Shooter;

import java.io.File;

import com.pathplanner.lib.auto.AutoBuilder;
import com.pathplanner.lib.auto.NamedCommands;

import swervelib.SwerveInputStream;

/**
 * This class is where the bulk of the robot should be declared. Since Command-based is a "declarative" paradigm, very
 * little robot logic should actually be handled in the {@link Robot} periodic methods (other than the scheduler calls).
 * Instead, the structure of the robot (including subsystems, commands, and trigger mappings) should be declared here.
 */

public class RobotContainer
{

  final CommandXboxController driverXbox = new CommandXboxController(0);
  final CommandXboxController operatorXbox = new CommandXboxController(1); 
  final CommandXboxController sysIdXbox = new CommandXboxController(2); 

  private final Limelight limelightLeft = new Limelight(Constants.Limelight.LIMELIGHT_LEFT_NAME);
  private final Limelight limelightRight = new Limelight(Constants.Limelight.LIMELIGHT_RIGHT_NAME);
  private final Limelight limelightFront = new Limelight(Constants.Limelight.LIMELIGHT_FRONT_NAME); 

  // The robot's subsystems and commands are defined here...
  private final SwerveSubsystem       drivebase  = new SwerveSubsystem(new File(Filesystem.getDeployDirectory(), "swerve"), 
                                                                                limelightLeft, limelightRight, limelightFront);
  // Establish a Sendable Chooser that will be able to be sent to the SmartDashboard, allowing selection of desired auto
  private final SendableChooser<Command> autoChooser;

  private final Shooter shooter = new Shooter(Constants.Shooter.MOTOR_R1_ID, Constants.Shooter.MOTOR_R2_ID,
                                              Constants.Shooter.MOTOR_L1_ID, Constants.Shooter.MOTOR_L2_ID);
  private final Intake intake = new Intake(Constants.Intake.MOTOR_ID);
  private final Indexer indexer = new Indexer(Constants.Indexer.MOTOR_ID);
  private final Kicker kicker = new Kicker(Constants.Kicker.MOTOR_ID); 
  private final Pivot pivot = new Pivot(Constants.Pivot.MOTOR_ID);
  private final Hood hood = new Hood (Constants.Hood.MOTOR_ID);
  private final ProjectileEstimation estimation = new ProjectileEstimation(drivebase);

  /**
   * Converts driver input into a field-relative ChassisSpeeds that is controlled by angular velocity.
   */

  private SwerveInputStream driveAngularVelocity = SwerveInputStream.of(drivebase.getSwerveDrive(),
                                                                () -> driverXbox.getLeftY() * -1,
                                                                () -> driverXbox.getLeftX() * -1)
                                                            .withControllerRotationAxis(()-> driverXbox.getRightX() * -1)
                                                            .deadband(OperatorConstants.DEADBAND)
                                                            .scaleTranslation(1)
                                                            .allianceRelativeControl(true);

  private Command driveFieldOrientedAnglularVelocity = drivebase.driveFieldOriented(driveAngularVelocity);

  /**
   * The container for the robot. Contains subsystems, OI devices, and commands.
   */
  public RobotContainer()
  {
    // Configure the trigger bindings
    configureBindings();
    DriverStation.silenceJoystickConnectionWarning(true);
    drivebase.replaceSwerveModuleFeedforward(0.1241005, 2.2384, 0.1936025);
    SmartDashboard.putData(drivebase);
    
    //Put the autoChooser on the SmartDashboard
    registerAutoCommands();
    autoChooser = AutoBuilder.buildAutoChooser();
    SmartDashboard.putData("Auto Chooser", autoChooser);
  }

  /**
   * Use this method to define your trigger->command mappings. Triggers can be created via the
   * {@link Trigger#Trigger(java.util.function.BooleanSupplier)} constructor with an arbitrary predicate, or via the
   * named factories in {@link 
   * edu.wpi.first.wpilibj2.command.button.CommandGenericHID}'s subclasses for
   * {@link CommandXboxController Xbox}/{@link edu.wpi.first.wpilibj2.command.button.CommandPS4Controller PS4}
   * controllers or {@link edu.wpi.first.wpilibj2.command.button.CommandJoystick Flight joysticks}.
   */
  private void configureBindings()
  {
    //driver controls
    drivebase.setDefaultCommand(driveFieldOrientedAnglularVelocity);
    driverXbox.start().onTrue(Commands.runOnce(drivebase::zeroGyroWithAlliance));    

    // driverXbox.a().whileTrue(new Agitate(pivot, intake));
    driverXbox.a().whileTrue(new AgitateFurther(pivot, intake));
    driverXbox.x().whileTrue(new LockSwerve(drivebase));

    driverXbox.leftTrigger().whileTrue(new SpinIntake(intake, -Constants.Intake.SPEED));
    driverXbox.rightTrigger().whileTrue(new SpinIntake(intake, Constants.Intake.SPEED));

    if(Constants.Alliance.BLUE()) {
      driverXbox.leftBumper().whileTrue(new AdjustedAlignTo(drivebase, ()-> driverXbox.getLeftY(), ()-> -driverXbox.getLeftX(), estimation));
      driverXbox.rightBumper().whileTrue(new SwerveAlignToPass(drivebase, ()-> driverXbox.getLeftY(), ()-> -driverXbox.getLeftX()));
    }
    else { 
      driverXbox.leftBumper().whileTrue(new AdjustedAlignTo(drivebase, ()-> driverXbox.getLeftY(), ()-> driverXbox.getLeftX(), estimation));
      driverXbox.rightBumper().whileTrue(new SwerveAlignToPass(drivebase, ()-> driverXbox.getLeftY(), ()-> driverXbox.getLeftX()));
    }

    driverXbox.povUp().whileTrue(new AbsoluteDrive(drivebase, () -> Constants.DrivebaseConstants.FINE_DRIVE_SPEED, () ->0.0, () ->0.0, () ->0.0));
    driverXbox.povDown().whileTrue(new AbsoluteDrive(drivebase, () -> -Constants.DrivebaseConstants.FINE_DRIVE_SPEED, () ->0.0, () ->0.0, () ->0.0));
    driverXbox.povRight().whileTrue(new AbsoluteDrive(drivebase, () -> 0.0, ()-> -Constants.DrivebaseConstants.FINE_DRIVE_SPEED, () ->0.0, () ->0.0));
    driverXbox.povLeft().whileTrue(new AbsoluteDrive(drivebase, () -> 0.0, () -> Constants.DrivebaseConstants.FINE_DRIVE_SPEED, () ->0.0, () ->0.0));

    //operator controls
    operatorXbox.a().toggleOnTrue(new PivotGoTo(pivot, Constants.Pivot.INTAKE_POSITION));
    operatorXbox.x().toggleOnTrue(new PivotGoTo(pivot, Constants.Pivot.STOWED_POSITION));
    operatorXbox.b().whileTrue(new Pass(shooter, hood, kicker, indexer));
    
    operatorXbox.y().whileTrue(new Shoot(shooter, hood, kicker, indexer, estimation));


    // operatorXbox.y().whileTrue(new CollectShooterData(shooter, kicker, indexer, Constants.Shooter.TEST_RPM));

    operatorXbox.start().whileTrue(new AgitateFurther(pivot, intake));

    operatorXbox.axisMagnitudeGreaterThan(Constants.OperatorConstants.LEFT_Y, Constants.DEADBAND).whileTrue(new ControlPivot(pivot, ()-> operatorXbox.getLeftY() * Constants.Pivot.SPEED));
    operatorXbox.axisMagnitudeGreaterThan(Constants.OperatorConstants.RIGHT_Y, Constants.DEADBAND).whileTrue(new SpinIndexer(indexer, ()-> operatorXbox.getRightY() * Constants.Intake.SPEED));

    operatorXbox.povLeft().whileTrue(new SpinKicker(kicker, -Constants.Kicker.KICKER_SPEED));
    operatorXbox.povRight().whileTrue(new SpinKicker(kicker, Constants.Kicker.KICKER_SPEED));
    operatorXbox.povUp().whileTrue(new CollectShooterData(shooter, kicker, indexer, Constants.Shooter.BACKUP_RPM_BOOST));

    operatorXbox.leftTrigger().whileTrue(new ControlHood(hood, -Constants.Hood.SPEED));
    operatorXbox.rightTrigger().whileTrue(new ControlHood(hood, Constants.Hood.SPEED));

    operatorXbox.leftBumper().whileTrue(new CollectShooterData(shooter, kicker, indexer, Constants.Shooter.BACKUP_RPM));
    
    operatorXbox.rightBumper().whileTrue(new AdjustedSpinShooter(shooter, estimation));
  }

  /**
   * Use this to pass the autonomous command to the main {@link Robot} class.
   *
   * @return the command to run in autonomous
   */
  public Command getAutonomousCommand()
  {
    // Pass in the selected auto from the SmartDashboard as our desired autnomous commmand 
    return autoChooser.getSelected();
  }

  public void setMotorBrake(boolean brake)
  {
    drivebase.setMotorBrake(brake);
  }

  public Limelight getLimelightRight()
  {
    return limelightRight;
  }

  public Limelight getLimelightLeft()
  {
    return limelightLeft;
  }

  public Limelight getLimelightFront() {
    return limelightFront; 
  }

  public SwerveSubsystem getDrivebase()
  {
    return drivebase;
  }

  public void registerAutoCommands() {
    
    NamedCommands.registerCommand("feed balls", new FeedShooter(kicker, indexer));
    NamedCommands.registerCommand("prepare shooter", new PrepareShooter(
                       shooter, hood, estimation));
    NamedCommands.registerCommand("pivot stow", new PivotGoTo(pivot, Constants.Pivot.STOWED_POSITION));
    NamedCommands.registerCommand("pivot down", new PivotGoTo(pivot, Constants.Pivot.INTAKE_POSITION));
  
    NamedCommands.registerCommand("intake", new SpinIntake(intake, Constants.Intake.SPEED));
    NamedCommands.registerCommand("agitate", new AgitateFurther(pivot, intake));

    NamedCommands.registerCommand("kicker outtake", new SpinKicker(kicker, -Constants.Kicker.KICKER_SPEED/2));
    NamedCommands.registerCommand("indexer outtake", new SpinIndexer(indexer, ()-> -Constants.Indexer.INDEXER_SPEED/2));

    NamedCommands.registerCommand("auto align", new AdjustedAlignTo(drivebase, ()-> 0, ()-> 0, estimation));
  }
}
