// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

package frc.robot;

import edu.wpi.first.wpilibj.DriverStation;
import edu.wpi.first.wpilibj.TimedRobot;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj2.command.Command;
import edu.wpi.first.wpilibj2.command.CommandScheduler;
import frc.robot.commands.LockSwerve;

/**
 * The VM is configured to automatically run this class, and to call the functions corresponding to each mode, as
 * described in the TimedRobot documentation. If you change the name of this class or the package after creating this
 * project, you must also update the build.gradle file in the project.
 */
public class Robot extends TimedRobot
{
  // private PowerDistribution powerDistribution;

  private static Robot   instance;
  private        Command m_autonomousCommand;

  private RobotContainer m_robotContainer;

  public Robot()
  {
    instance = this;
  }

  public static Robot getInstance()
  {
    return instance;
  }

  /**
   * This function is run when the robot is first started up and should be used for any initialization code.
   */
  @Override
  public void robotInit()
  {
    // Instantiate our RobotContainer.  This will perform all our button bindings, and put our
    // autonomous chooser on the dashboard.
    m_robotContainer = new RobotContainer();

    //new PDP object to monitor current draw on the dashboard for debugging purposes.  Not necessary for actual robot operation.
    // powerDistribution = new PowerDistribution();

    if (isSimulation())
    {
      DriverStation.silenceJoystickConnectionWarning(true);
    }

    m_robotContainer.getDrivebase().setMotorBrake(false);

  }

  /**
   * This function is called every 20 ms, no matter the mode. Use this for items like diagnostics that you want ran
   * during disabled, autonomous, teleoperated and test.
   *
   * <p>This runs after the mode specific periodic functions, but before LiveWindow and
   * SmartDashboard integrated updating.
   */
  @Override
  public void robotPeriodic()
  {
    SmartDashboard.putBoolean("Alliance Blue?", Constants.Alliance.BLUE());

    // Runs the Scheduler.  This is responsible for polling buttons, adding newly-scheduled
    // commands, running already-scheduled commands, removing finished or interrupted commands,
    // and running subsystem periodic() methods.  This must be called from the robot's periodic
    // block in order for anything in the Command-based framework to work.
    CommandScheduler.getInstance().run();
    
    //CURRENT DRAW
    // SmartDashboard.putNumber("Total Current Draw", powerDistribution.getTotalCurrent());

    // //swerve
    // SmartDashboard.putNumber("Front Right Drive Current", powerDistribution.getCurrent(Constants.DrivebaseConstants.FRD_PDP_PORT));//Front Right Drive
    // SmartDashboard.putNumber("Front Right Angle Current", powerDistribution.getCurrent(Constants.DrivebaseConstants.FRA_PDP_PORT));//Front Right Angle
    // SmartDashboard.putNumber("Front Left Drive Current", powerDistribution.getCurrent(Constants.DrivebaseConstants.FLD_PDP_PORT));//Front Left Drive
    // SmartDashboard.putNumber("Front Left Angle Current", powerDistribution.getCurrent(Constants.DrivebaseConstants.FLA_PDP_PORT));//Front Left Angle
    // SmartDashboard.putNumber("Back Right Drive Current", powerDistribution.getCurrent(Constants.DrivebaseConstants.BRD_PDP_PORT));//Back Right Drive
    // SmartDashboard.putNumber("Back Right Angle Current", powerDistribution.getCurrent(Constants.DrivebaseConstants.BRA_PDP_PORT));//Back Right Angle
    // SmartDashboard.putNumber("Back Left Drive Current", powerDistribution.getCurrent(Constants.DrivebaseConstants.BLD_PDP_PORT));//Back Left Drive
    // SmartDashboard.putNumber("Back Left Angle Current", powerDistribution.getCurrent(Constants.DrivebaseConstants.BLA_PDP_PORT));//Back Left Angle

    // // intake + pivot + indexer
    // SmartDashboard.putNumber("Intake Current Draw", powerDistribution.getCurrent(Constants.Intake.PDP_PORT));
    // SmartDashboard.putNumber("Pivot Current Draw", powerDistribution.getCurrent(Constants.Pivot.PDP_PORT));
    // SmartDashboard.putNumber("Indexer Current Draw", powerDistribution.getCurrent(Constants.Indexer.PDP_PORT));

    // // shooter
    // SmartDashboard.putNumber("Shooter Lower Left Current Draw", powerDistribution.getCurrent(Constants.Shooter.LOWER_LEFT_PDP_PORT));
    // SmartDashboard.putNumber("Shooter Upper Right Current Draw", powerDistribution.getCurrent(Constants.Shooter.UPPER_RIGHT_PDP_PORT));
    // SmartDashboard.putNumber("Shooter Lower Right Current Draw", powerDistribution.getCurrent(Constants.Shooter.LOWER_RIGHT_PDP_PORT));
    // SmartDashboard.putNumber("Shooter Upper Left Current Draw", powerDistribution.getCurrent(Constants.Shooter.UPPER_LEFT_PDP_PORT));
    // SmartDashboard.putNumber("Hood Current Draw", powerDistribution.getCurrent(Constants.Hood.PDP_PORT));
  }

  /**
   * This function is called once each time the robot enters Disabled mode.
   */
  @Override

  public void disabledInit()
  {
    m_robotContainer.getDrivebase().setMotorBrake(false);
  }
  
  @Override

  public void disabledPeriodic()
  {
  }

  /**
   * This autonomous runs the autonomous command selected by your {@link RobotContainer} class.
   */
  @Override
  public void autonomousInit()
  {
    m_autonomousCommand = m_robotContainer.getAutonomousCommand();
    m_robotContainer.getDrivebase().setMotorBrake(true);
    // schedule the autonomous command (example)
    if (m_autonomousCommand != null)
    {
      m_autonomousCommand.schedule();
    }
    
  }

  /**
   * This function is called periodically during autonomous.
   */
  @Override
  public void autonomousPeriodic()
  {
  }

  @Override
  public void teleopInit()
  {
    m_robotContainer.getDrivebase().setMotorBrake(true);

    // This makes sure that the autonomous stops running when
    // teleop starts running. If you want the autonomous to
    // continue until interrupted by another command, remove
    // this line or comment it out.
    if (m_autonomousCommand != null)
    {
      m_autonomousCommand.cancel();
    } else
    {
      CommandScheduler.getInstance().cancelAll();
    }
  }

  /**
   * This function is called periodically during operator control.
   */
  @Override
  public void teleopPeriodic()
  {
  }

  @Override
  public void testInit()
  {}

  /**
   * This function is called periodically during test mode.
   */
  @Override
  public void testPeriodic()
  {
  }

  /**
   * This function is called once when the robot is first started up.
   */
  @Override
  public void simulationInit()
  {
  }

  /**
   * This function is called periodically whilst in simulation.
   */
  @Override
  public void simulationPeriodic()
  {
  }

}
